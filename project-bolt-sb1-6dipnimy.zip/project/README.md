# DC Payroll System

A comprehensive payroll processing system designed specifically for companies in the Philippines, featuring accurate salary computation based on Philippine labor standards.

## Features

- **Employee Management**: Add, edit, and delete employee records
- **Payroll Processing**: Calculate salaries with proper Philippine deductions
- **Time Tracking**: Monitor employee attendance and work hours
- **Payslip Generation**: Create and export detailed payslips
- **Reports & Analytics**: View payroll summaries and department breakdowns
- **User Authentication**: Secure login system with role-based access

## Technical Stack

- **Frontend**: React.js with Tailwind CSS
- **Backend**: Node.js with Express.js
- **Database**: PostgreSQL
- **Authentication**: JWT-based authentication

## Philippine-specific Calculations

The system includes accurate calculations for:

- SSS Contributions (2025 rates)
- PhilHealth Contributions (2025 rates)
- Pag-IBIG Contributions
- Withholding Tax based on TRAIN Law
- Overtime Pay (125% of regular rate)
- Night Differential (110% of regular rate)
- Holiday Pay (200% of regular rate)
- Late and Undertime deductions

## Getting Started

### Prerequisites

- Node.js (v18 or later)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm run dev
   ```

### Demo Credentials

- **Email**: admin@dcpayroll.com
- **Password**: admin123

## Screenshots

(Screenshots would be included here in a real README)

## License

This project is licensed under the MIT License.