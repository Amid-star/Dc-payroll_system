import React from 'react';
import { 
  Users, DollarSign, Clock, CalendarCheck, CreditCard, 
  TrendingUp, TrendingDown, Briefcase 
} from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import Card from '../components/ui/Card';

const Dashboard: React.FC = () => {
  // Mock data for dashboard statistics
  const stats = [
    { name: 'Total Employees', value: '124', icon: Users, change: '+4%', trend: 'up' },
    { name: 'Payroll This Month', value: '₱1,245,350', icon: DollarSign, change: '+2.5%', trend: 'up' },
    { name: 'Average Salary', value: '₱32,450', icon: CreditCard, change: '+1.2%', trend: 'up' },
    { name: 'Pending Approvals', value: '5', icon: Clock, change: '-3', trend: 'down' },
  ];

  // Mock data for department breakdown
  const departments = [
    { name: 'Engineering', employeeCount: 42, budget: '₱850,000' },
    { name: 'Marketing', employeeCount: 24, budget: '₱420,000' },
    { name: 'Finance', employeeCount: 18, budget: '₱380,000' },
    { name: 'HR', employeeCount: 12, budget: '₱280,000' },
    { name: 'Operations', employeeCount: 28, budget: '₱520,000' },
  ];

  // Mock data for recent payroll activities
  const recentActivities = [
    { id: 1, activity: 'May 2025 Payroll Processed', date: '2 days ago', status: 'completed' },
    { id: 2, activity: 'New employee John Doe onboarded', date: '3 days ago', status: 'completed' },
    { id: 3, activity: 'Tax deductions updated for all employees', date: '5 days ago', status: 'completed' },
    { id: 4, activity: 'April 2025 Payroll Processed', date: '15 days ago', status: 'completed' },
  ];

  return (
    <DashboardLayout>
      <div className="px-4 py-6 sm:px-6 lg:px-8">
        <div className="sm:flex sm:items-center sm:justify-between">
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <div className="mt-3 sm:mt-0">
            <div className="inline-flex rounded-md shadow-sm">
              <button
                type="button"
                className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                <CalendarCheck className="h-5 w-5 mr-2 text-gray-500" />
                Run Payroll
              </button>
            </div>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.name} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className={`h-12 w-12 rounded-md flex items-center justify-center ${
                    stat.name.includes('Pending') ? 'bg-warning/10 text-warning' : 'bg-primary-500/10 text-primary-600'
                  }`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">{stat.name}</dt>
                    <dd>
                      <div className="text-lg font-semibold text-gray-900">{stat.value}</div>
                    </dd>
                  </dl>
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                {stat.trend === 'up' ? (
                  <TrendingUp className="h-4 w-4 text-success" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-error" />
                )}
                <span className={`ml-2 ${
                  stat.trend === 'up' ? 'text-success' : 'text-error'
                }`}>
                  {stat.change}
                </span>
                <span className="ml-2 text-gray-500">from last month</span>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Department Breakdown */}
          <Card title="Department Breakdown" className="lg:col-span-2">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Department
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Employees
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Payroll Budget
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {departments.map((department) => (
                    <tr key={department.name}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center bg-primary-100 rounded-md">
                            <Briefcase className="h-5 w-5 text-primary-600" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{department.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {department.employeeCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {department.budget}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Recent Activities */}
          <Card title="Recent Activities">
            <div className="flow-root">
              <ul role="list" className="-mb-8">
                {recentActivities.map((activity, activityIdx) => (
                  <li key={activity.id}>
                    <div className="relative pb-8">
                      {activityIdx !== recentActivities.length - 1 ? (
                        <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true" />
                      ) : null}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className={`h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white ${
                            activity.status === 'completed' ? 'bg-success' : 'bg-blue-500'
                          }`}>
                            <CalendarCheck className="h-5 w-5 text-white" />
                          </span>
                        </div>
                        <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                          <div>
                            <p className="text-sm text-gray-800">{activity.activity}</p>
                          </div>
                          <div className="text-sm text-gray-500 whitespace-nowrap">
                            <time>{activity.date}</time>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;