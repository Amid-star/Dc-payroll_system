// Philippine payroll calculation utility functions

// SSS Contribution calculation based on 2025 rates
export const calculateSSSContribution = (monthlySalary: number): number => {
  if (monthlySalary < 4250) return 180;
  if (monthlySalary <= 4749.99) return 202.50;
  if (monthlySalary <= 5249.99) return 225;
  if (monthlySalary <= 5749.99) return 247.50;
  if (monthlySalary <= 6249.99) return 270;
  if (monthlySalary <= 6749.99) return 292.50;
  if (monthlySalary <= 7249.99) return 315;
  if (monthlySalary <= 7749.99) return 337.50;
  if (monthlySalary <= 8249.99) return 360;
  if (monthlySalary <= 8749.99) return 382.50;
  if (monthlySalary <= 9249.99) return 405;
  if (monthlySalary <= 9749.99) return 427.50;
  if (monthlySalary <= 10249.99) return 450;
  if (monthlySalary <= 10749.99) return 472.50;
  if (monthlySalary <= 11249.99) return 495;
  if (monthlySalary <= 11749.99) return 517.50;
  if (monthlySalary <= 12249.99) return 540;
  if (monthlySalary <= 12749.99) return 562.50;
  if (monthlySalary <= 13249.99) return 585;
  if (monthlySalary <= 13749.99) return 607.50;
  if (monthlySalary <= 14249.99) return 630;
  if (monthlySalary <= 14749.99) return 652.50;
  if (monthlySalary <= 15249.99) return 675;
  if (monthlySalary <= 15749.99) return 697.50;
  if (monthlySalary <= 16249.99) return 720;
  if (monthlySalary <= 16749.99) return 742.50;
  if (monthlySalary <= 17249.99) return 765;
  if (monthlySalary <= 17749.99) return 787.50;
  if (monthlySalary <= 18249.99) return 810;
  if (monthlySalary <= 18749.99) return 832.50;
  if (monthlySalary <= 19249.99) return 855;
  if (monthlySalary <= 19749.99) return 877.50;
  if (monthlySalary <= 20249.99) return 900;
  // Continue with the 2025 SSS contribution table
  return 1125; // Maximum contribution for 2025
};

// PhilHealth contribution calculation - 2025 rates
export const calculatePhilHealthContribution = (monthlySalary: number): number => {
  // 2025 PhilHealth rate is expected to be 4%
  const rate = 0.04;
  const monthlyPremium = monthlySalary * rate;
  
  // Minimum and maximum premium amounts
  const minPremium = 400; // Minimum for those earning below 10,000
  const maxPremium = 3200; // Maximum for those earning above 80,000
  
  if (monthlySalary < 10000) {
    return minPremium / 2; // Employee share (50% of premium)
  } else if (monthlySalary > 80000) {
    return maxPremium / 2; // Employee share (50% of premium)
  } else {
    return monthlyPremium / 2; // Employee share (50% of premium)
  }
};

// Pag-IBIG contribution calculation - 2025 rates
export const calculatePagIBIGContribution = (monthlySalary: number): number => {
  if (monthlySalary <= 1500) {
    return monthlySalary * 0.01; // 1% for those earning 1,500 and below
  } else {
    return Math.min(100, monthlySalary * 0.02); // 2% up to a maximum of 100
  }
};

// Withholding tax calculation based on TRAIN Law
export const calculateWithholdingTax = (
  monthlySalary: number, 
  sssContribution: number, 
  philHealthContribution: number, 
  pagIBIGContribution: number,
  taxStatus: 'single' | 'married' | 'head_of_family'
): number => {
  // Calculate taxable income
  const totalDeductions = sssContribution + philHealthContribution + pagIBIGContribution;
  const taxableIncome = monthlySalary - totalDeductions;
  
  // Apply tax rates based on TRAIN Law
  let tax = 0;
  
  // Adjust personal exemption based on tax status
  const personalExemption = taxStatus === 'head_of_family' ? 50000 / 12 : 
                           taxStatus === 'married' ? 50000 / 12 : 
                           25000 / 12;
  
  const adjustedTaxableIncome = Math.max(0, taxableIncome - personalExemption);
  
  // Tax computation
  if (adjustedTaxableIncome <= 20833) {
    tax = 0;
  } else if (adjustedTaxableIncome <= 33332) {
    tax = (adjustedTaxableIncome - 20833) * 0.20;
  } else if (adjustedTaxableIncome <= 66666) {
    tax = 2500 + (adjustedTaxableIncome - 33333) * 0.25;
  } else if (adjustedTaxableIncome <= 166666) {
    tax = 10833.33 + (adjustedTaxableIncome - 66667) * 0.30;
  } else if (adjustedTaxableIncome <= 666666) {
    tax = 40833.33 + (adjustedTaxableIncome - 166667) * 0.32;
  } else {
    tax = 200833.33 + (adjustedTaxableIncome - 666667) * 0.35;
  }
  
  return tax;
};

// Calculate overtime pay
export const calculateOvertimePay = (hourlyRate: number, overtimeHours: number): number => {
  return hourlyRate * overtimeHours * 1.25;
};

// Calculate night differential
export const calculateNightDifferential = (hourlyRate: number, nightHours: number): number => {
  return hourlyRate * nightHours * 0.10;
};

// Calculate regular holiday pay
export const calculateRegularHolidayPay = (dailyRate: number, hoursWorked: number): number => {
  const hourlyRate = dailyRate / 8;
  return hourlyRate * hoursWorked * 2; // 200% of regular rate
};

// Calculate late deduction
export const calculateLateDeduction = (hourlyRate: number, lateMinutes: number): number => {
  return hourlyRate * (lateMinutes / 60);
};

// Calculate undertime deduction
export const calculateUndertimeDeduction = (hourlyRate: number, undertimeMinutes: number): number => {
  return hourlyRate * (undertimeMinutes / 60);
};

// Calculate net pay
export const calculateNetPay = (
  basicPay: number,
  overtimePay: number,
  nightDifferential: number,
  holidayPay: number,
  lateDeduction: number,
  undertimeDeduction: number,
  sssContribution: number,
  philHealthContribution: number,
  pagIBIGContribution: number,
  taxWithheld: number
): number => {
  const grossPay = basicPay + overtimePay + nightDifferential + holidayPay;
  const totalDeductions = lateDeduction + undertimeDeduction + sssContribution + 
                         philHealthContribution + pagIBIGContribution + taxWithheld;
  
  return grossPay - totalDeductions;
};