// Auth Types
export type User = {
  id: number;
  username: string;
  email: string;
  role: 'admin' | 'hr' | 'viewer';
  firstName: string;
  lastName: string;
};

export type AuthState = {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
};

// Employee Types
export type Employee = {
  id: number;
  employeeId: string;
  firstName: string;
  lastName: string;
  email: string;
  position: string;
  department: string;
  dateHired: string;
  basicSalary: number;
  taxStatus: 'single' | 'married' | 'head_of_family';
  sssNumber: string;
  philhealthNumber: string;
  pagibigNumber: string;
  tinNumber: string;
  status: 'active' | 'inactive';
};

// Payroll Types
export type PayrollPeriod = {
  id: number;
  name: string;
  startDate: string;
  endDate: string;
  type: 'bi-monthly' | 'monthly';
  status: 'draft' | 'processing' | 'completed';
};

export type PayrollEntry = {
  id: number;
  employeeId: number;
  periodId: number;
  basicPay: number;
  overtimePay: number;
  nightDifferential: number;
  holidayPay: number;
  lateDeduction: number;
  undertimeDeduction: number;
  sssContribution: number;
  philhealthContribution: number;
  pagibigContribution: number;
  taxWithheld: number;
  netPay: number;
  grossPay: number;
  totalDeductions: number;
};

export type Payslip = PayrollEntry & {
  employee: Employee;
  period: PayrollPeriod;
};

// Dashboard Types
export type PayrollSummary = {
  totalEmployees: number;
  totalBasicPay: number;
  totalOvertimePay: number;
  totalDeductions: number;
  totalNetPay: number;
};

export type DepartmentSummary = {
  department: string;
  employeeCount: number;
  totalSalary: number;
};

// Time Record Types
export type TimeRecord = {
  id: number;
  employeeId: number;
  date: string;
  timeIn: string;
  timeOut: string;
  regularHours: number;
  overtimeHours: number;
  nightHours: number;
  isHoliday: boolean;
  holidayType: 'regular' | 'special' | 'none';
};