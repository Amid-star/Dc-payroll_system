import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthState } from '../types';

// Define the context type
type AuthContextType = {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  clearError: () => void;
};

// Create context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
  login: async () => {},
  logout: () => {},
  clearError: () => {},
});

// Context provider component
export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    token: localStorage.getItem('token'),
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  // Check if user is authenticated on mount
  useEffect(() => {
    const loadUser = async () => {
      if (authState.token) {
        try {
          // In a real app, validate token with the server
          // For now, we'll simulate it with mock data
          const user: User = {
            id: 1,
            username: 'admin',
            email: 'admin@dcpayroll.com',
            role: 'admin',
            firstName: 'Admin',
            lastName: 'User',
          };

          setAuthState({
            ...authState,
            isAuthenticated: true,
            isLoading: false,
            user,
          });
        } catch (err) {
          localStorage.removeItem('token');
          setAuthState({
            ...authState,
            token: null,
            isAuthenticated: false,
            isLoading: false,
          });
        }
      } else {
        setAuthState({
          ...authState,
          isLoading: false,
        });
      }
    };

    loadUser();
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    try {
      setAuthState({
        ...authState,
        isLoading: true,
        error: null,
      });

      // In real app, this would be an API call
      // For demo, we'll use mock data
      if (email === 'admin@dcpayroll.com' && password === 'admin123') {
        const user: User = {
          id: 1,
          username: 'admin',
          email: 'admin@dcpayroll.com',
          role: 'admin',
          firstName: 'Admin',
          lastName: 'User',
        };
        
        const token = 'mock-jwt-token';
        
        // Store token in localStorage
        localStorage.setItem('token', token);
        
        setAuthState({
          user,
          token,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (err) {
      setAuthState({
        ...authState,
        isLoading: false,
        error: err instanceof Error ? err.message : 'Login failed',
      });
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('token');
    setAuthState({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });
  };

  // Clear error
  const clearError = () => {
    setAuthState({
      ...authState,
      error: null,
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user: authState.user,
        token: authState.token,
        isAuthenticated: authState.isAuthenticated,
        isLoading: authState.isLoading,
        error: authState.error,
        login,
        logout,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use the auth context
export const useAuth = () => useContext(AuthContext);