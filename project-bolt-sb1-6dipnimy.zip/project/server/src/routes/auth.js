import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const router = express.Router();

// Mock users for demo (in real app, would be fetched from database)
const users = [
  {
    id: 1,
    username: 'admin',
    email: 'admin@dcpayroll.com',
    password: '$2a$10$XxVLhQ3xRyJfkuWr.Xo4XOBQhEuIY1CG0Cr5iJo9x7sEMrpIW2IFG', // admin123
    role: 'admin',
    firstName: 'Admin',
    lastName: 'User'
  },
  {
    id: 2,
    username: 'hr',
    email: 'hr@dcpayroll.com',
    password: '$2a$10$XxVLhQ3xRyJfkuWr.Xo4XOBQhEuIY1CG0Cr5iJo9x7sEMrpIW2IFG', // admin123
    role: 'hr',
    firstName: 'HR',
    lastName: 'Manager'
  }
];

// Route to handle user login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate user input
    if (!email || !password) {
      return res.status(400).json({ message: 'Please provide email and password' });
    }

    // Find user by email
    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Create JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      'your_jwt_secret', // In production, this would be in environment variables
      { expiresIn: '1d' }
    );

    // Remove password from user object
    const { password: _, ...userWithoutPassword } = user;

    // Return user info and token
    res.json({
      user: userWithoutPassword,
      token
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Middleware to verify JWT token
export const authMiddleware = (req, res, next) => {
  try {
    // Get token from header
    const token = req.header('Authorization').replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    // Verify token
    const decoded = jwt.verify(token, 'your_jwt_secret');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ message: 'Token is not valid' });
  }
};

// Route to get current user
router.get('/me', authMiddleware, async (req, res) => {
  try {
    // Find user by id from token
    const user = users.find(u => u.id === req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Remove password from user object
    const { password: _, ...userWithoutPassword } = user;

    // Return user info
    res.json(userWithoutPassword);
  } catch (err) {
    console.error('Get user error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;