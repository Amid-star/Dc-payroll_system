import express from 'express';
import { authMiddleware } from './auth.js';

const router = express.Router();

// Mock time records data
let timeRecords = [
  {
    id: 1,
    employeeId: 1,
    date: '2025-05-01',
    timeIn: '08:00',
    timeOut: '17:30',
    regularHours: 8,
    overtimeHours: 1.5,
    nightHours: 0,
    isHoliday: false,
    holidayType: 'none'
  },
  {
    id: 2,
    employeeId: 1,
    date: '2025-05-02',
    timeIn: '08:15',
    timeOut: '17:00',
    regularHours: 7.75,
    overtimeHours: 0,
    nightHours: 0,
    isHoliday: false,
    holidayType: 'none'
  },
  {
    id: 3,
    employeeId: 2,
    date: '2025-05-01',
    timeIn: '08:05',
    timeOut: '18:30',
    regularHours: 8,
    overtimeHours: 2.5,
    nightHours: 0,
    isHoliday: false,
    holidayType: 'none'
  }
];

// Get all time records
router.get('/', authMiddleware, (req, res) => {
  // Optional filtering by employee and date range
  let filtered = [...timeRecords];
  
  if (req.query.employeeId) {
    const employeeId = parseInt(req.query.employeeId);
    filtered = filtered.filter(record => record.employeeId === employeeId);
  }
  
  if (req.query.startDate && req.query.endDate) {
    filtered = filtered.filter(record => {
      const recordDate = new Date(record.date);
      const startDate = new Date(req.query.startDate);
      const endDate = new Date(req.query.endDate);
      return recordDate >= startDate && recordDate <= endDate;
    });
  }
  
  res.json(filtered);
});

// Get a single time record
router.get('/:id', authMiddleware, (req, res) => {
  const record = timeRecords.find(r => r.id === parseInt(req.params.id));
  
  if (!record) {
    return res.status(404).json({ message: 'Time record not found' });
  }
  
  res.json(record);
});

// Create a new time record
router.post('/', authMiddleware, (req, res) => {
  const {
    employeeId, date, timeIn, timeOut, isHoliday, holidayType
  } = req.body;
  
  // Basic validation
  if (!employeeId || !date || !timeIn || !timeOut) {
    return res.status(400).json({ message: 'Please provide all required fields' });
  }
  
  // Calculate hours worked
  const timeInHours = parseFloat(timeIn.split(':')[0]) + parseFloat(timeIn.split(':')[1]) / 60;
  const timeOutHours = parseFloat(timeOut.split(':')[0]) + parseFloat(timeOut.split(':')[1]) / 60;
  
  let totalHours = timeOutHours - timeInHours;
  if (totalHours < 0) totalHours += 24; // Handle overnight shifts
  
  // Regular hours (max 8)
  const regularHours = Math.min(8, totalHours);
  
  // Overtime hours
  const overtimeHours = Math.max(0, totalHours - 8);
  
  // Night hours (10pm to 6am, simplified calculation)
  let nightHours = 0;
  const nightStartHour = 22; // 10pm
  const nightEndHour = 6; // 6am
  
  if (timeInHours < nightEndHour || timeOutHours > nightStartHour) {
    // Simplistic calculation - can be improved for accuracy
    if (timeInHours < nightEndHour && timeOutHours <= nightEndHour) {
      // Shift starts and ends during night hours (before 6am)
      nightHours = timeOutHours - timeInHours;
    } else if (timeInHours >= nightStartHour && timeOutHours > nightStartHour) {
      // Shift starts and ends during night hours (after 10pm)
      nightHours = timeOutHours - timeInHours;
    } else if (timeInHours < nightEndHour && timeOutHours > nightEndHour) {
      // Shift starts during night hours and ends during day
      nightHours = nightEndHour - timeInHours;
    } else if (timeInHours < nightStartHour && timeOutHours > nightStartHour) {
      // Shift starts during day and ends during night hours
      nightHours = timeOutHours - nightStartHour;
    }
  }
  
  // Create new time record
  const newRecord = {
    id: timeRecords.length + 1,
    employeeId,
    date,
    timeIn,
    timeOut,
    regularHours,
    overtimeHours,
    nightHours,
    isHoliday: isHoliday || false,
    holidayType: holidayType || 'none'
  };
  
  timeRecords.push(newRecord);
  
  res.status(201).json(newRecord);
});

// Update a time record
router.put('/:id', authMiddleware, (req, res) => {
  const recordIndex = timeRecords.findIndex(r => r.id === parseInt(req.params.id));
  
  if (recordIndex === -1) {
    return res.status(404).json({ message: 'Time record not found' });
  }
  
  // Update record fields
  const updatedRecord = {
    ...timeRecords[recordIndex],
    ...req.body,
    id: timeRecords[recordIndex].id // Prevent id change
  };
  
  // If time in or out was updated, recalculate hours
  if (req.body.timeIn || req.body.timeOut) {
    const timeIn = req.body.timeIn || timeRecords[recordIndex].timeIn;
    const timeOut = req.body.timeOut || timeRecords[recordIndex].timeOut;
    
    // Calculate hours worked
    const timeInHours = parseFloat(timeIn.split(':')[0]) + parseFloat(timeIn.split(':')[1]) / 60;
    const timeOutHours = parseFloat(timeOut.split(':')[0]) + parseFloat(timeOut.split(':')[1]) / 60;
    
    let totalHours = timeOutHours - timeInHours;
    if (totalHours < 0) totalHours += 24; // Handle overnight shifts
    
    // Regular hours (max 8)
    updatedRecord.regularHours = Math.min(8, totalHours);
    
    // Overtime hours
    updatedRecord.overtimeHours = Math.max(0, totalHours - 8);
    
    // Night hours calculation would be similar to the POST route
    // Simplified for brevity
  }
  
  timeRecords[recordIndex] = updatedRecord;
  
  res.json(updatedRecord);
});

// Delete a time record
router.delete('/:id', authMiddleware, (req, res) => {
  const recordIndex = timeRecords.findIndex(r => r.id === parseInt(req.params.id));
  
  if (recordIndex === -1) {
    return res.status(404).json({ message: 'Time record not found' });
  }
  
  // Remove record
  timeRecords.splice(recordIndex, 1);
  
  res.json({ message: 'Time record deleted successfully' });
});

export default router;