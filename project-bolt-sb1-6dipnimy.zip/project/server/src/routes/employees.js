import express from 'express';
import { authMiddleware } from './auth.js';

const router = express.Router();

// Mock employee data (would come from database in production)
let employees = [
  {
    id: 1,
    employeeId: 'EMP-001',
    firstName: 'Juan',
    lastName: 'Dela Cruz',
    email: 'juan@example.com',
    position: 'Senior Developer',
    department: 'Engineering',
    dateHired: '2021-03-15',
    basicSalary: 60000,
    taxStatus: 'single',
    sssNumber: '1234567890',
    philhealthNumber: '0987654321',
    pagibigNumber: '5432167890',
    tinNumber: '987654321001',
    status: 'active'
  },
  {
    id: 2,
    employeeId: 'EMP-002',
    firstName: 'Maria',
    lastName: 'Santos',
    email: 'maria@example.com',
    position: 'Marketing Manager',
    department: 'Marketing',
    dateHired: '2020-06-22',
    basicSalary: 55000,
    taxStatus: 'married',
    sssNumber: '0987654321',
    philhealthNumber: '1234567890',
    pagibigNumber: '1234567890',
    tinNumber: '123456789001',
    status: 'active'
  },
  {
    id: 3,
    employeeId: 'EMP-003',
    firstName: 'Pedro',
    lastName: 'Reyes',
    email: 'pedro@example.com',
    position: 'Financial Analyst',
    department: 'Finance',
    dateHired: '2022-01-10',
    basicSalary: 45000,
    taxStatus: 'head_of_family',
    sssNumber: '5678901234',
    philhealthNumber: '4321098765',
    pagibigNumber: '3456789012',
    tinNumber: '456789012001',
    status: 'active'
  }
];

// Get all employees
router.get('/', authMiddleware, (req, res) => {
  res.json(employees);
});

// Get a single employee
router.get('/:id', authMiddleware, (req, res) => {
  const employee = employees.find(emp => emp.id === parseInt(req.params.id));
  
  if (!employee) {
    return res.status(404).json({ message: 'Employee not found' });
  }
  
  res.json(employee);
});

// Create a new employee
router.post('/', authMiddleware, (req, res) => {
  const {
    firstName, lastName, email, position, department,
    dateHired, basicSalary, taxStatus, sssNumber,
    philhealthNumber, pagibigNumber, tinNumber
  } = req.body;
  
  // Basic validation
  if (!firstName || !lastName || !email || !position || !basicSalary) {
    return res.status(400).json({ message: 'Please provide all required fields' });
  }
  
  // Create new employee
  const newEmployee = {
    id: employees.length + 1,
    employeeId: `EMP-${String(employees.length + 1).padStart(3, '0')}`,
    firstName,
    lastName,
    email,
    position,
    department,
    dateHired: dateHired || new Date().toISOString().split('T')[0],
    basicSalary,
    taxStatus: taxStatus || 'single',
    sssNumber: sssNumber || '',
    philhealthNumber: philhealthNumber || '',
    pagibigNumber: pagibigNumber || '',
    tinNumber: tinNumber || '',
    status: 'active'
  };
  
  employees.push(newEmployee);
  
  res.status(201).json(newEmployee);
});

// Update an employee
router.put('/:id', authMiddleware, (req, res) => {
  const employeeIndex = employees.findIndex(emp => emp.id === parseInt(req.params.id));
  
  if (employeeIndex === -1) {
    return res.status(404).json({ message: 'Employee not found' });
  }
  
  // Update employee fields
  const updatedEmployee = {
    ...employees[employeeIndex],
    ...req.body,
    id: employees[employeeIndex].id, // Prevent id change
    employeeId: employees[employeeIndex].employeeId // Prevent employeeId change
  };
  
  employees[employeeIndex] = updatedEmployee;
  
  res.json(updatedEmployee);
});

// Delete an employee (soft delete - set status to inactive)
router.delete('/:id', authMiddleware, (req, res) => {
  const employeeIndex = employees.findIndex(emp => emp.id === parseInt(req.params.id));
  
  if (employeeIndex === -1) {
    return res.status(404).json({ message: 'Employee not found' });
  }
  
  // Soft delete - set status to inactive
  employees[employeeIndex] = {
    ...employees[employeeIndex],
    status: 'inactive'
  };
  
  res.json({ message: 'Employee deleted successfully' });
});

export default router;