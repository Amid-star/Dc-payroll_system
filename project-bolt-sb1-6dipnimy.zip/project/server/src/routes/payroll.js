import express from 'express';
import { authMiddleware } from './auth.js';

const router = express.Router();

// Mock payroll periods data
let payrollPeriods = [
  {
    id: 1,
    name: 'May 2025 - First Half',
    startDate: '2025-05-01',
    endDate: '2025-05-15',
    type: 'bi-monthly',
    status: 'completed'
  },
  {
    id: 2,
    name: 'May 2025 - Second Half',
    startDate: '2025-05-16',
    endDate: '2025-05-31',
    type: 'bi-monthly',
    status: 'processing'
  }
];

// Mock payroll entries data
let payrollEntries = [
  {
    id: 1,
    employeeId: 1,
    periodId: 1,
    basicPay: 30000,
    overtimePay: 2500,
    nightDifferential: 1200,
    holidayPay: 0,
    lateDeduction: 450,
    undertimeDeduction: 0,
    sssContribution: 1125,
    philhealthContribution: 600,
    pagibigContribution: 100,
    taxWithheld: 3500,
    grossPay: 33700,
    totalDeductions: 5775,
    netPay: 27925
  },
  {
    id: 2,
    employeeId: 2,
    periodId: 1,
    basicPay: 27500,
    overtimePay: 1800,
    nightDifferential: 0,
    holidayPay: 0,
    lateDeduction: 0,
    undertimeDeduction: 320,
    sssContribution: 1080,
    philhealthContribution: 550,
    pagibigContribution: 100,
    taxWithheld: 3200,
    grossPay: 29300,
    totalDeductions: 5250,
    netPay: 24050
  }
];

// Get all payroll periods
router.get('/periods', authMiddleware, (req, res) => {
  res.json(payrollPeriods);
});

// Get a single payroll period
router.get('/periods/:id', authMiddleware, (req, res) => {
  const period = payrollPeriods.find(p => p.id === parseInt(req.params.id));
  
  if (!period) {
    return res.status(404).json({ message: 'Payroll period not found' });
  }
  
  res.json(period);
});

// Create a new payroll period
router.post('/periods', authMiddleware, (req, res) => {
  const { name, startDate, endDate, type } = req.body;
  
  // Basic validation
  if (!name || !startDate || !endDate || !type) {
    return res.status(400).json({ message: 'Please provide all required fields' });
  }
  
  // Create new period
  const newPeriod = {
    id: payrollPeriods.length + 1,
    name,
    startDate,
    endDate,
    type,
    status: 'draft'
  };
  
  payrollPeriods.push(newPeriod);
  
  res.status(201).json(newPeriod);
});

// Update a payroll period
router.put('/periods/:id', authMiddleware, (req, res) => {
  const periodIndex = payrollPeriods.findIndex(p => p.id === parseInt(req.params.id));
  
  if (periodIndex === -1) {
    return res.status(404).json({ message: 'Payroll period not found' });
  }
  
  // Update period fields
  const updatedPeriod = {
    ...payrollPeriods[periodIndex],
    ...req.body,
    id: payrollPeriods[periodIndex].id // Prevent id change
  };
  
  payrollPeriods[periodIndex] = updatedPeriod;
  
  res.json(updatedPeriod);
});

// Get payroll entries for a specific period
router.get('/periods/:periodId/entries', authMiddleware, (req, res) => {
  const periodId = parseInt(req.params.periodId);
  const entries = payrollEntries.filter(entry => entry.periodId === periodId);
  
  res.json(entries);
});

// Get a single payroll entry
router.get('/entries/:id', authMiddleware, (req, res) => {
  const entry = payrollEntries.find(e => e.id === parseInt(req.params.id));
  
  if (!entry) {
    return res.status(404).json({ message: 'Payroll entry not found' });
  }
  
  res.json(entry);
});

// Create a new payroll entry
router.post('/entries', authMiddleware, (req, res) => {
  const {
    employeeId, periodId, basicPay, overtimePay, nightDifferential, holidayPay,
    lateDeduction, undertimeDeduction, sssContribution, philhealthContribution,
    pagibigContribution, taxWithheld
  } = req.body;
  
  // Basic validation
  if (!employeeId || !periodId || basicPay === undefined) {
    return res.status(400).json({ message: 'Please provide all required fields' });
  }
  
  // Calculate derived values
  const grossPay = (basicPay || 0) + (overtimePay || 0) + (nightDifferential || 0) + (holidayPay || 0);
  const totalDeductions = (lateDeduction || 0) + (undertimeDeduction || 0) + 
                         (sssContribution || 0) + (philhealthContribution || 0) + 
                         (pagibigContribution || 0) + (taxWithheld || 0);
  const netPay = grossPay - totalDeductions;
  
  // Create new entry
  const newEntry = {
    id: payrollEntries.length + 1,
    employeeId,
    periodId,
    basicPay: basicPay || 0,
    overtimePay: overtimePay || 0,
    nightDifferential: nightDifferential || 0,
    holidayPay: holidayPay || 0,
    lateDeduction: lateDeduction || 0,
    undertimeDeduction: undertimeDeduction || 0,
    sssContribution: sssContribution || 0,
    philhealthContribution: philhealthContribution || 0,
    pagibigContribution: pagibigContribution || 0,
    taxWithheld: taxWithheld || 0,
    grossPay,
    totalDeductions,
    netPay
  };
  
  payrollEntries.push(newEntry);
  
  res.status(201).json(newEntry);
});

// Update a payroll entry
router.put('/entries/:id', authMiddleware, (req, res) => {
  const entryIndex = payrollEntries.findIndex(e => e.id === parseInt(req.params.id));
  
  if (entryIndex === -1) {
    return res.status(404).json({ message: 'Payroll entry not found' });
  }
  
  // Get the updated values
  const updatedValues = {
    ...payrollEntries[entryIndex],
    ...req.body,
    id: payrollEntries[entryIndex].id // Prevent id change
  };
  
  // Recalculate derived values
  const grossPay = (updatedValues.basicPay || 0) + (updatedValues.overtimePay || 0) + 
                   (updatedValues.nightDifferential || 0) + (updatedValues.holidayPay || 0);
  const totalDeductions = (updatedValues.lateDeduction || 0) + (updatedValues.undertimeDeduction || 0) + 
                         (updatedValues.sssContribution || 0) + (updatedValues.philhealthContribution || 0) + 
                         (updatedValues.pagibigContribution || 0) + (updatedValues.taxWithheld || 0);
  const netPay = grossPay - totalDeductions;
  
  // Update entry with recalculated values
  const updatedEntry = {
    ...updatedValues,
    grossPay,
    totalDeductions,
    netPay
  };
  
  payrollEntries[entryIndex] = updatedEntry;
  
  res.json(updatedEntry);
});

// Generate payslips for a period
router.get('/periods/:periodId/payslips', authMiddleware, (req, res) => {
  const periodId = parseInt(req.params.periodId);
  
  // Check if period exists
  const period = payrollPeriods.find(p => p.id === periodId);
  if (!period) {
    return res.status(404).json({ message: 'Payroll period not found' });
  }
  
  // Get entries for the period
  const entries = payrollEntries.filter(entry => entry.periodId === periodId);
  
  // Mock employees data (in a real app, would be fetched from DB)
  const employees = [
    {
      id: 1,
      employeeId: 'EMP-001',
      firstName: 'Juan',
      lastName: 'Dela Cruz',
      position: 'Senior Developer',
      department: 'Engineering'
    },
    {
      id: 2,
      employeeId: 'EMP-002',
      firstName: 'Maria',
      lastName: 'Santos',
      position: 'Marketing Manager',
      department: 'Marketing'
    }
  ];
  
  // Generate payslips by combining entry data with employee data
  const payslips = entries.map(entry => {
    const employee = employees.find(emp => emp.id === entry.employeeId);
    
    return {
      ...entry,
      employee,
      period
    };
  });
  
  res.json(payslips);
});

export default router;