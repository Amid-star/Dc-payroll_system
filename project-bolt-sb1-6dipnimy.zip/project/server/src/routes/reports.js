import express from 'express';
import { authMiddleware } from './auth.js';

const router = express.Router();

// Mock data for reports
const generateMockReportData = () => {
  // Payroll summary by period
  const payrollSummaryByPeriod = [
    {
      periodId: 1,
      periodName: 'May 2025 - First Half',
      totalEmployees: 124,
      totalBasicPay: 3750000,
      totalOvertimePay: 287500,
      totalNightDifferential: 45600,
      totalHolidayPay: 135000,
      totalDeductions: 1175000,
      totalNetPay: 3043100
    },
    {
      periodId: 2,
      periodName: 'May 2025 - Second Half',
      totalEmployees: 124,
      totalBasicPay: 3750000,
      totalOvertimePay: 312000,
      totalNightDifferential: 52800,
      totalHolidayPay: 0,
      totalDeductions: 1150000,
      totalNetPay: 2964800
    }
  ];

  // Department summary
  const departmentSummary = [
    {
      department: 'Engineering',
      employeeCount: 42,
      totalSalary: 2520000,
      averageSalary: 60000
    },
    {
      department: 'Marketing',
      employeeCount: 24,
      totalSalary: 1320000,
      averageSalary: 55000
    },
    {
      department: 'Finance',
      employeeCount: 18,
      totalSalary: 810000,
      averageSalary: 45000
    },
    {
      department: 'HR',
      employeeCount: 12,
      totalSalary: 540000,
      averageSalary: 45000
    },
    {
      department: 'Operations',
      employeeCount: 28,
      totalSalary: 1260000,
      averageSalary: 45000
    }
  ];

  // Monthly trends (6 months)
  const monthlyTrends = [
    {
      month: 'January 2025',
      totalPayroll: 5750000,
      averageSalary: 46371
    },
    {
      month: 'February 2025',
      totalPayroll: 5800000,
      averageSalary: 46774
    },
    {
      month: 'March 2025',
      totalPayroll: 5925000,
      averageSalary: 47782
    },
    {
      month: 'April 2025',
      totalPayroll: 5980000,
      averageSalary: 48225
    },
    {
      month: 'May 2025',
      totalPayroll: 6007900,
      averageSalary: 48450
    }
  ];

  // Deduction summary
  const deductionSummary = {
    sss: 580000,
    philhealth: 296000,
    pagibig: 124000,
    tax: 1425000
  };

  return {
    payrollSummaryByPeriod,
    departmentSummary,
    monthlyTrends,
    deductionSummary
  };
};

// Get payroll summary by period
router.get('/payroll-summary', authMiddleware, (req, res) => {
  const data = generateMockReportData();
  res.json(data.payrollSummaryByPeriod);
});

// Get department summary
router.get('/department-summary', authMiddleware, (req, res) => {
  const data = generateMockReportData();
  res.json(data.departmentSummary);
});

// Get monthly trends
router.get('/monthly-trends', authMiddleware, (req, res) => {
  const data = generateMockReportData();
  res.json(data.monthlyTrends);
});

// Get deduction summary
router.get('/deduction-summary', authMiddleware, (req, res) => {
  const data = generateMockReportData();
  res.json(data.deductionSummary);
});

// Get comprehensive report
router.get('/comprehensive', authMiddleware, (req, res) => {
  const data = generateMockReportData();
  res.json(data);
});

export default router;