import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pg from 'pg';
import employeeRoutes from './routes/employees.js';
import payrollRoutes from './routes/payroll.js';
import authRoutes from './routes/auth.js';
import timeRecordRoutes from './routes/timeRecords.js';
import reportRoutes from './routes/reports.js';

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Database setup (commented out until actual DB is connected)
/*
const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

// Test DB connection
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('Error connecting to the database:', err);
  } else {
    console.log('Database connected successfully');
  }
});

// Make the pool available to routes
app.locals.db = pool;
*/

// Routes
app.use('/api/employees', employeeRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/time-records', timeRecordRoutes);
app.use('/api/reports', reportRoutes);

// Base route
app.get('/', (req, res) => {
  res.send('DC Payroll System API is running');
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});